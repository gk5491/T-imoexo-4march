<?php
require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/db_config.php';

// Use the database connection function from db_config.php
$db = getDbConnection();

session_start();

$data = json_decode(file_get_contents("php://input"));
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action === 'login') {
    if (!empty($data->username) && !empty($data->password)) {
        $query = "SELECT id, username, password, email, role, permissions, status FROM admin_users WHERE username = ? LIMIT 1";
        $stmt = $db->prepare($query);
        $stmt->execute([$data->username]);

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Check if account is active
            if (isset($row['status']) && $row['status'] === 'disabled') {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'message' => 'Your account has been disabled. Please contact administrator.'
                ]);
                exit;
            }

            if (password_verify($data->password, $row['password'])) {
                // Parse permissions
                $permissions = !empty($row['permissions']) ? json_decode($row['permissions'], true) : null;
                
                // Start session and store user info
                $_SESSION['admin_id'] = $row['id'];
                $_SESSION['admin_username'] = $row['username'];
                $_SESSION['admin_email'] = $row['email'];
                $_SESSION['admin_role'] = $row['role'] ?? 'user';
                $_SESSION['admin_permissions'] = $permissions;
                
                // Update last_login
                $updateStmt = $db->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = ?");
                $updateStmt->execute([$row['id']]);

                http_response_code(200);
                echo json_encode([
                    'success' => true,
                    'message' => 'Login successful',
                    'user' => [
                        'id' => $row['id'],
                        'username' => $row['username'],
                        'email' => $row['email'],
                        'role' => $row['role'] ?? 'user',
                        'permissions' => $permissions
                    ]
                ]);
            } else {
                http_response_code(401);
                echo json_encode([
                    'success' => false,
                    'message' => 'Invalid credentials'
                ]);
            }
        } else {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'message' => 'User not found'
            ]);
        }
    } else {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Username and password required'
        ]);
    }
} elseif ($action === 'logout') {
    session_destroy();

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Logout successful'
    ]);
} elseif ($action === 'check') {
    if (isset($_SESSION['admin_id'])) {
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'authenticated' => true,
            'user' => [
                'id' => $_SESSION['admin_id'],
                'username' => $_SESSION['admin_username'],
                'email' => $_SESSION['admin_email'] ?? null,
                'role' => $_SESSION['admin_role'] ?? 'user',
                'permissions' => $_SESSION['admin_permissions'] ?? null
            ]
        ]);
    } else {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'authenticated' => false
        ]);
    }
} else {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid action'
    ]);
}
