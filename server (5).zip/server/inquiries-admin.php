<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/db_config.php';

try {
    $db = getDbConnection();
    session_start();

    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit();
    }

    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                $id = intval($_GET['id']);
                $type = isset($_GET['type']) ? $_GET['type'] : null;
                
                $inquiry = null;
                $foundType = null;
                
                if ($type) {
                    $table = '';
                    switch ($type) {
                        case 'buyer':
                            $table = 'buyer_inquiries';
                            break;
                        case 'manufacturer':
                            $table = 'manufacturer_inquiries';
                            break;
                        case 'contact':
                            $table = 'contact_submissions';
                            break;
                        default:
                            $type = null;
                    }
                    
                    if ($table) {
                        // Use SELECT * for buyer and manufacturer, but specific fields with alias for contact
                        if ($type === 'contact') {
                            $query = "SELECT id, name, email, phone, country, requirement as requirements, 
                                      source_page, created_at, status FROM $table WHERE id = ?";
                        } else {
                            $query = "SELECT * FROM $table WHERE id = ?";
                        }
                        $stmt = $db->prepare($query);
                        $stmt->execute([$id]);
                        $inquiry = $stmt->fetch(PDO::FETCH_ASSOC);
                        if ($inquiry) {
                            $foundType = $type;
                        }
                    }
                }
                
                if (!$inquiry) {
                    $tables = [
                        'buyer' => 'buyer_inquiries',
                        'manufacturer' => 'manufacturer_inquiries',
                        'contact' => 'contact_submissions'
                    ];
                    
                    foreach ($tables as $searchType => $table) {
                        // Use SELECT * for buyer and manufacturer, but specific fields with alias for contact
                        if ($searchType === 'contact') {
                            $query = "SELECT id, name, email, phone, country, requirement as requirements, 
                                      source_page, created_at, status FROM $table WHERE id = ?";
                        } else {
                            $query = "SELECT * FROM $table WHERE id = ?";
                        }
                        $stmt = $db->prepare($query);
                        $stmt->execute([$id]);
                        $result = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($result) {
                            $inquiry = $result;
                            $foundType = $searchType;
                            break;
                        }
                    }
                }

                if ($inquiry) {
                    $inquiry['inquiry_type'] = $foundType;
                    echo json_encode(['success' => true, 'data' => $inquiry]);
                } else {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'Inquiry not found']);
                }
            } else {
                $filterType = isset($_GET['filter']) ? $_GET['filter'] : 'all';
                $inquiries = [];

                if ($filterType === 'all' || $filterType === 'buyer') {
                    $query = "SELECT id, company_name as name, contact_person, email, phone, country, 
                              product_category, quantity, requirements, created_at, status 
                              FROM buyer_inquiries ORDER BY created_at DESC";
                    $stmt = $db->prepare($query);
                    $stmt->execute();
                    $buyers = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($buyers as $buyer) {
                        $buyer['inquiry_type'] = 'buyer';
                        $buyer['type_label'] = 'Buyer Inquiry';
                        $inquiries[] = $buyer;
                    }
                }

                if ($filterType === 'all' || $filterType === 'manufacturer') {
                    $query = "SELECT id, company_name as name, contact_person, email, phone, country, 
                              product_category, production_capacity, requirements, created_at, status 
                              FROM manufacturer_inquiries ORDER BY created_at DESC";
                    $stmt = $db->prepare($query);
                    $stmt->execute();
                    $manufacturers = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($manufacturers as $manufacturer) {
                        $manufacturer['inquiry_type'] = 'manufacturer';
                        $manufacturer['type_label'] = 'Manufacturer Inquiry';
                        $inquiries[] = $manufacturer;
                    }
                }

                if ($filterType === 'all' || $filterType === 'contact') {
                    $query = "SELECT id, name, email, phone, country, requirement as requirements, 
                              source_page, created_at, status 
                              FROM contact_submissions ORDER BY created_at DESC";
                    $stmt = $db->prepare($query);
                    $stmt->execute();
                    $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($contacts as $contact) {
                        $contact['inquiry_type'] = 'contact';
                        $contact['type_label'] = 'Contact Inquiry';
                        $inquiries[] = $contact;
                    }
                }

                usort($inquiries, function($a, $b) {
                    return strtotime($b['created_at']) - strtotime($a['created_at']);
                });

                echo json_encode(['success' => true, 'data' => $inquiries]);
            }
            break;

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($input['id']) || !isset($input['type']) || !isset($input['status'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Missing required fields']);
                exit();
            }
            
            $id = intval($input['id']);
            $type = $input['type'];
            $status = $input['status'];
            
            // Validate status value
            $validStatuses = ['new', 'contacted', 'in_progress', 'closed', 'dead_lead'];
            if (!in_array($status, $validStatuses)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid status value']);
                exit();
            }
            
            // Determine table based on type
            $table = '';
            switch ($type) {
                case 'buyer':
                    $table = 'buyer_inquiries';
                    break;
                case 'manufacturer':
                    $table = 'manufacturer_inquiries';
                    break;
                case 'contact':
                    $table = 'contact_submissions';
                    break;
                default:
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Invalid inquiry type']);
                    exit();
            }
            
            // Update status
            $query = "UPDATE $table SET status = ? WHERE id = ?";
            $stmt = $db->prepare($query);
            $result = $stmt->execute([$status, $id]);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Status updated successfully']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Failed to update status']);
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
            break;
    }
} catch (Exception $e) {
    error_log("Error in inquiries-admin.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}