<?php
// Simple CORS test

// Allow all origins
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(["status" => "OK", "message" => "CORS preflight successful"]);
    exit();
}

echo json_encode(["status" => "OK", "message" => "Simple CORS test successful"]);
?>